package com.inhouse.services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InHouseServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(InHouseServicesApplication.class, args);
	}

}
