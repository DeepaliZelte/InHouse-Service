package com.inhouse.services.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.inhouse.services.model.Admin;
import com.inhouse.services.repository.AdminRepository;

@RestController
@CrossOrigin
public class AdminController {
	
	@Autowired
	private AdminRepository adminRepository;
	
	@PostMapping("/addAdmin")
	public String addAdmin(@RequestBody Admin admin) {
		adminRepository.save(admin);
		return "Added Successfully";
	}
	
	@PostMapping("/checkAdmin")
	public Admin adminLogin(@RequestBody Admin admin) {
		System.out.print("admin called");
		Admin adminObj=adminRepository.findAdminByAdminEmailAndAdminPassword(admin.getAdminEmail(),admin.getAdminPassword());
				
					return adminObj;
				
	}
	
	@GetMapping("/getAdmin")
	public String getAdmin() {
		return "Got it";
	}
	
	@PostMapping("/findadmin")
	public Admin findAdmin(@RequestBody Admin admin) {
		return adminRepository.findByAdminId(admin.getAdminId());
	}
	

}
