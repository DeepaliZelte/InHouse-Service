package com.inhouse.services.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.inhouse.services.model.Complaint;
import com.inhouse.services.model.Customer;
import com.inhouse.services.model.Employee;
import com.inhouse.services.model.Hire;
import com.inhouse.services.repository.ComplaintRepository;
import com.inhouse.services.repository.CustomerRepository;
import com.inhouse.services.repository.EmployeeRepository;

@RestController
@CrossOrigin
public class ComplaintController {
	
	@Autowired
	ComplaintRepository complaintRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	@GetMapping("/getallcomplaint")
	public List<Complaint> getAllComplaint(){
		return complaintRepository.findAll();
	}

	@PostMapping("/addComplaint")
	public Complaint addComplaint(@RequestBody Complaint complaint) {
		Customer cust=complaint.getCust();
		cust=customerRepository.findByCustId(cust.getCustId());
		
		Employee emp=complaint.getEmp();
		emp=employeeRepository.findByEmpId(emp.getEmpId());
		
		complaint.setCust(cust);
		complaint.setEmp(emp);
		Date date = new Date();
		String strDateFormat = "yyyy-MM-dd";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		String formattedDate = dateFormat.format(date);
		complaint.setDate(formattedDate);
		complaint.setStatus("pending");
				
		return complaintRepository.save(complaint);
	}
	
	
	
	@PostMapping("/getcompbycust")
	public List<Complaint> getHire(@RequestBody Complaint complaint){
		return complaintRepository.getCompCust(complaint.getCust().getCustId());
	}
	
	@PostMapping("/resolvecomstatus")
	public String resoveComStatus(@RequestBody Complaint com) {
		System.out.println("in resolve");
		com=complaintRepository.findByCompId(com.getCompId());
		com.setStatus("resolved");
		complaintRepository.save(com);
		return "resolved";
		
	}
	
	@PostMapping("/rejectcomstatus")
	public String rejectComStatus(@RequestBody Complaint com) {
		com=complaintRepository.findByCompId(com.getCompId());
		com.setStatus("rejected");
		complaintRepository.save(com);
		return "rejected";
		
	}
}
