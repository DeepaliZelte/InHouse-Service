package com.inhouse.services.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.inhouse.services.model.Customer;
import com.inhouse.services.model.Employee;
import com.inhouse.services.repository.CustomerRepository;

@RestController
@CrossOrigin
public class CustomerController {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@GetMapping("/customerList")
	public List<Customer> getCustomerList(){
		System.out.println("List caled");
		return customerRepository.findAll();
	}
	
	@PostMapping("/addCustomer")
	public String  addCustomer(@RequestBody Customer customer) {
		customerRepository.save(customer);
		return "Customer added";
	}
	
	@PostMapping("/checkCustomer")
	public Customer customerLogin(@RequestBody Customer customer) {
		
		Customer custObj=customerRepository.findCustomerByCustEmailAndCustPassword(customer.getCustEmail(),customer.getCustPassword());
		 return custObj;
	}
	
	@PostMapping("/updatecuststatus")
	public String updateCustStatus(@RequestBody Customer cust) {
		Customer customer=customerRepository.findByCustId(cust.getCustId());
		if(customer.getCustStatus().equals("active")){
			customer.setCustStatus("inactive");
		}else {
			customer.setCustStatus("active");
		}
		customerRepository.save(customer);
		return null;
		
		
	}
	
	
	@PostMapping("/findbycustid")
	public Customer findcustbyid(@RequestBody Customer customer) {
		return customerRepository.findByCustId(customer.getCustId());
	}
	
	
	@Autowired
	private EmplyeeController emplyeeController;
	@PostMapping("/forgetcustPass")
	public String confirmCustomer(@RequestBody Customer user) {

		//OTP otp1 = new OTP();

		Customer tr = this.customerRepository.findByCustEmail(user.getCustEmail());
		if (tr != null) {
			//int otp = random.nextInt(999999);
		
			String subject = "Message from Inhouse services";
			String message = "Your password is = " + tr.getCustPassword() +" Please do no share with anyone";
			String to = tr.getCustEmail();
//			otp1.setOtp(otp);

			boolean flag = emplyeeController.sendEmail(subject, message, to);

			if (flag == true) {
				
//				otp1.setStatus("success");
				return "success";
			} else {

			
				
				return "Something went wrong";
			}
		} else {

			System.out.println("not successfull");
			return "Your email is not found";
		}

	}

	

}
