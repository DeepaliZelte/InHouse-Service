package com.inhouse.services.controller;

import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.inhouse.services.model.Employee;
import com.inhouse.services.repository.EmployeeRepository;

@RestController
@CrossOrigin
public class EmplyeeController {

	Random random = new Random(10000);
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@GetMapping("/employeeList")
	public List<Employee> employeeList(){
		return employeeRepository.findAll();
	}
	
	@PostMapping("/addEmployee")
	public String addEmployee(@RequestBody Employee employee) {
		
		employeeRepository.save(employee);
		return "employee added";
	}
	
	@PostMapping("/checkEmployee")
	public Employee employeelogin(@RequestBody Employee employee) {
		Employee emp1=employeeRepository.findEmployeeByEmpEmailAndEmpPassword(employee.getEmpEmail(),employee.getEmpPassword());
		return emp1;
	}
	
	@PostMapping("/updateempstatus")
	public String updateEmpStatus(@RequestBody Employee emp) {
		Employee employee=employeeRepository.findByEmpId(emp.getEmpId());
		if(employee.getEmpStatus().equals("active")){
		employee.setEmpStatus("inactive");
		}else {
			employee.setEmpStatus("active");
		}
		employeeRepository.save(employee);
		return null;
		
		
	}
	
	@GetMapping("/getallcities")
	public List<Employee> findAllCities(){
		System.out.println("in city list");
		return employeeRepository.findAllCities();
	}
	
	@PostMapping("/getbycity")
	public List<Employee> getByCity(@RequestBody Employee emp){
		return employeeRepository.findByEmpCity(emp.getEmpCity());
	}
	
	@GetMapping("/getallprofession")
	public List<Employee> findAllProfession(){
		return employeeRepository.findAllProfession();
	}
	
	@PostMapping("/getbyprofession")
	public List<Employee> getByProfession(@RequestBody Employee emp){
		return employeeRepository.findByProfession(emp.getProfession());
	}
	
	
	@PostMapping("/findempbyid")
	public Employee findempbyid(@RequestBody Employee employee) {
		return employeeRepository.findByEmpId(employee.getEmpId());
	}
	
	
	@PostMapping("/forgetPass")
	public String confirmEmployee(@RequestBody Employee user) {

		//OTP otp1 = new OTP();

		Employee tr = this.employeeRepository.findByEmpEmail(user.getEmpEmail());
		if (tr != null) {
			//int otp = random.nextInt(999999);
		
			String subject = "Message from Inhouse services";
			String message = "Your password is = " + tr.getEmpPassword() +" Please do no share with anyone";
			String to = tr.getEmpEmail();
//			otp1.setOtp(otp);

			boolean flag = this.sendEmail(subject, message, to);

			if (flag == true) {
				
//				otp1.setStatus("success");
				return "success";
			} else {

			
				
				return "Something went wrong";
			}
		} else {

			System.out.println("not successfull");
			return "Your email is not found";
		}

	}
	
	
	
	public boolean sendEmail(String subject, String message, String to)
	{
		boolean bool=false;
		String from="inhouseservices7@gmail.com";
		String host="smtp.gmail.com";
		
		//get system property
		Properties properties=System.getProperties();
		System.out.println("PROPERTIES "+properties);
		
		//host set
		
		properties.put("mail.smtp.host",host);
		properties.put("mail.smtp.port","465");
		properties.put("mail.smtp.ssl.enable","true");
		properties.put("mail.smtp.auth","true");
		
		//step1: to get the session object
		
		Session session=Session.getInstance(properties,new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("inhouseservices7@gmail.com","Admin@123");
			}}
			);
		
		session.setDebug(true);
		
		MimeMessage m=new MimeMessage(session);
		
		try {
			
			m.setFrom(from);
			
			m.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			
			m.setSubject(subject);
			
			//adding text
			m.setText(message);
			
			//step3 send the message 
			Transport.send(m);
			System.out.println("sent success......");
			bool=true;
			
			
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
		
		return bool;
	}
	
}
