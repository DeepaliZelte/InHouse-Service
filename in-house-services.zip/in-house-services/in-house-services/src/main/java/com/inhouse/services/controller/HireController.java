package com.inhouse.services.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.inhouse.services.model.Customer;
import com.inhouse.services.model.Employee;
import com.inhouse.services.model.Hire;
import com.inhouse.services.repository.CustomerRepository;
import com.inhouse.services.repository.EmployeeRepository;
import com.inhouse.services.repository.HireRepository;

@RestController
@CrossOrigin
public class HireController {

	@Autowired
	private HireRepository hireRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@PostMapping("/addHire")
	public String addHire(@RequestBody Hire hire) {
		Customer cust = hire.getCust();
		cust = customerRepository.findByCustId(cust.getCustId());
		Employee emp = hire.getEmp();
		emp = employeeRepository.findByEmpId(emp.getEmpId());

		hire.setCust(cust);
		hire.setEmp(emp);
		hireRepository.save(hire);
		return "hire request added";

	}
	@PostMapping("/gethirebycust")
	public List<Hire> getHire(@RequestBody Hire hire){
		return hireRepository.getHireCust(hire.getCust().getCustId());
	}

	@GetMapping("/gethire")
	public List<Hire> getAllHire() {
return hireRepository.findAll();
	}
	
	@PostMapping("/cancelbooking")
	public String cancelBooking(@RequestBody Hire hire) {
		hire=hireRepository.findByHireId(hire.getHireId());
		System.out.println("inthe fun");
		if(hire.getHireStatus().equals("pending")) {
			hire.setHireStatus("Cancelled");
			hireRepository.save(hire);
			return "Your Booking is Cancelled";
		}else {
			return "You Already cancelled this booking";
		}
		
		
	}
	
	
	@PostMapping("/gethirebyemp")
	public List<Hire> getHirelist(@RequestBody Hire hire){
		return hireRepository.getHireEmp(hire.getEmp().getEmpId());
	}
	
	
	@PostMapping("/acceptbooking")
	public String acceptBooking(@RequestBody Hire hire) {
		hire=hireRepository.findByHireId(hire.getHireId());
		System.out.println("inthe fun");
		if(hire.getHireStatus().equals("pending")) {
			hire.setHireStatus("accepted");
			hireRepository.save(hire);
			return "You Accept this Booking request ";
		}else {
			return "You Already Accept this booking request";
		}
		
		
	}
	
	@PostMapping("/rejectbooking")
	public String rejectBooking(@RequestBody Hire hire) {
		hire=hireRepository.findByHireId(hire.getHireId());
		System.out.println("inthe fun");
		if(hire.getHireStatus().equals("rejected")) {
			return "You Already Reject this booking request";
		}else {
			
			hire.setHireStatus("rejected");
			hireRepository.save(hire);
			return "You Reject this Booking request ";
		}
		
		
	}
	

}
