package com.inhouse.services.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

 

@Entity
public class Complaint {
	@Id
	@GeneratedValue
	private int compId;
	private String complainer;
	@OneToOne
	private Customer cust;
	@OneToOne
	private Employee emp;
	private String issue;
	private String discription;
	private String date;
	private String status;
	private String remark;
	
	public Complaint() {
		super();
		
	}

	public Complaint(int compId, String complainer, Customer cust, Employee emp, String issue, String discription,
			String date, String status, String remark) {
		super();
		this.compId = compId;
		this.complainer = complainer;
		this.cust = cust;
		this.emp = emp;
		this.issue = issue;
		this.discription = discription;
		this.date = date;
		this.status = status;
		this.remark = remark;
	}

	public Complaint(String complainer, Customer cust, Employee emp, String issue, String discription, String date,
			String status, String remark) {
		super();
		this.complainer = complainer;
		this.cust = cust;
		this.emp = emp;
		this.issue = issue;
		this.discription = discription;
		this.date = date;
		this.status = status;
		this.remark = remark;
	}

	public int getCompId() {
		return compId;
	}

	public void setCompId(int compId) {
		this.compId = compId;
	}

	public String getComplainer() {
		return complainer;
	}

	public void setComplainer(String complainer) {
		this.complainer = complainer;
	}

	public Customer getCust() {
		return cust;
	}

	public void setCust(Customer cust) {
		this.cust = cust;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "Complaint [compId=" + compId + ", complainer=" + complainer + ", cust=" + cust + ", emp=" + emp
				+ ", issue=" + issue + ", discription=" + discription + ", date=" + date + ", status=" + status
				+ ", remark=" + remark + "]";
	}
	
	
	
	
}
