package com.inhouse.services.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue
	private int custId;
	private String custName;
	private String custGender;
	private String custAddress;
	private String custContact;
	private String custEmail;
	private String custPassword;
	private String custStatus;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int custId, String custName, String custGender, String custAddress, String custContact,
			String custEmail, String custPassword, String custStatus) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custGender = custGender;
		this.custAddress = custAddress;
		this.custContact = custContact;
		this.custEmail = custEmail;
		this.custPassword = custPassword;
		this.custStatus = custStatus;
	}
	public Customer(String custName, String custGender, String custAddress, String custContact, String custEmail,
			String custPassword, String custStatus) {
		super();
		this.custName = custName;
		this.custGender = custGender;
		this.custAddress = custAddress;
		this.custContact = custContact;
		this.custEmail = custEmail;
		this.custPassword = custPassword;
		this.custStatus = custStatus;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustGender() {
		return custGender;
	}
	public void setCustGender(String custGender) {
		this.custGender = custGender;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public String getCustContact() {
		return custContact;
	}
	public void setCustContact(String custContact) {
		this.custContact = custContact;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public String getCustPassword() {
		return custPassword;
	}
	public void setCustPassword(String custPassword) {
		this.custPassword = custPassword;
	}
	public String getCustStatus() {
		return custStatus;
	}
	public void setCustStatus(String custStatus) {
		this.custStatus = custStatus;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", custGender=" + custGender + ", custAddress="
				+ custAddress + ", custContact=" + custContact + ", custEmail=" + custEmail + ", custPassword="
				+ custPassword + ", custStatus=" + custStatus + "]";
	}
	
	
	
	 	
	
}
