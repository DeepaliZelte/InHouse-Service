package com.inhouse.services.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue
	private int empId;
	private String empName;
	private String empAdharno;
	private String empGender;
	private String empAddress;
	private String empCity;
	private String empContact;
	private String profession;
	private double empExperience;
	private double empRatePerHr;
	private String empEmail;
	private String empPassword;
	private String empStatus;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String empName, String empAdharno, String empGender, String empAddress, String empCity,
			String empContact, String profession, double empExperience, double empRatePerHr, String empEmail,
			String empPassword, String empStatus) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAdharno = empAdharno;
		this.empGender = empGender;
		this.empAddress = empAddress;
		this.empCity = empCity;
		this.empContact = empContact;
		this.profession = profession;
		this.empExperience = empExperience;
		this.empRatePerHr = empRatePerHr;
		this.empEmail = empEmail;
		this.empPassword = empPassword;
		this.empStatus = empStatus;
	}

	public Employee(String empName, String empAdharno, String empGender, String empAddress, String empCity,
			String empContact, String profession, double empExperience, double empRatePerHr, String empEmail,
			String empPassword, String empStatus) {
		super();
		this.empName = empName;
		this.empAdharno = empAdharno;
		this.empGender = empGender;
		this.empAddress = empAddress;
		this.empCity = empCity;
		this.empContact = empContact;
		this.profession = profession;
		this.empExperience = empExperience;
		this.empRatePerHr = empRatePerHr;
		this.empEmail = empEmail;
		this.empPassword = empPassword;
		this.empStatus = empStatus;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAdharno() {
		return empAdharno;
	}

	public void setEmpAdharno(String empAdharno) {
		this.empAdharno = empAdharno;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public String getEmpCity() {
		return empCity;
	}

	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}

	public String getEmpContact() {
		return empContact;
	}

	public void setEmpContact(String empContact) {
		this.empContact = empContact;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public double getEmpExperience() {
		return empExperience;
	}

	public void setEmpExperience(double empExperience) {
		this.empExperience = empExperience;
	}

	public double getEmpRatePerHr() {
		return empRatePerHr;
	}

	public void setEmpRatePerHr(double empRatePerHr) {
		this.empRatePerHr = empRatePerHr;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public String getEmpStatus() {
		return empStatus;
	}

	public void setEmpStatus(String empStatus) {
		this.empStatus = empStatus;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empAdharno=" + empAdharno + ", empGender="
				+ empGender + ", empAddress=" + empAddress + ", empCity=" + empCity + ", empContact=" + empContact
				+ ", profession=" + profession + ", empExperience=" + empExperience + ", empRatePerHr=" + empRatePerHr
				+ ", empEmail=" + empEmail + ", empPassword=" + empPassword + ", empStatus=" + empStatus + "]";
	}
	
	
	
	
}
