package com.inhouse.services.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Hire {

	@Id
	@GeneratedValue
	private int hireId;
	
	@OneToOne
	private Customer cust;
	
	@OneToOne
	private Employee emp;
	
	private String hireStatus;
	private String hireDate;

	public Customer getCust() {
		return cust;
	}
	public void setCust(Customer cust) {
		this.cust = cust;
	}
	public Employee getEmp() {
		return emp;
	}
	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	public int getHireId() {
		return hireId;
	}
	public void setHireId(int hireId) {
		this.hireId = hireId;
	}
	
	public String getHireStatus() {
		return hireStatus;
	}
	public void setHireStatus(String hireStatus) {
		this.hireStatus = hireStatus;
	}
	public String getHireDate() {
		return hireDate;
	}
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
	public Hire(int hireId, Customer cust, Employee emp, String hireStatus, String hireDate) {
		super();
		this.hireId = hireId;
		this.cust = cust;
		this.emp = emp;
		this.hireStatus = hireStatus;
		this.hireDate = hireDate;
	}
	public Hire() {
		super();
	}
	public Hire(Customer cust, Employee emp, String hireStatus, String hireDate) {
		super();
		this.cust = cust;
		this.emp = emp;
		this.hireStatus = hireStatus;
		this.hireDate = hireDate;
	}
		
}
