package com.inhouse.services.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.inhouse.services.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {

	public Employee findEmployeeByEmpEmailAndEmpPassword(String empEmail,String empPassword);
	public Employee findByEmpId(int id);
	
	@Query("select e from Employee e group by e.empCity")
	public List<Employee> findAllCities();
	
	public List<Employee> findByEmpCity(String city);
	
	@Query("select e from Employee e group by e.profession")
	public List<Employee> findAllProfession();
	
	public List<Employee> findByProfession(String profession);
	public Employee findByEmpEmail(String email);
	
	
}
