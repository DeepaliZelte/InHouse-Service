package com.inhouse.services.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.inhouse.services.model.Customer;
import com.inhouse.services.model.Hire;

@Repository
public interface HireRepository extends JpaRepository<Hire,Integer> {
	
	
	@Query("select h from Hire h where cust_cust_id=:id")
	public List<Hire> getHireCust(@Param("id") int id);
	
	public Hire findByHireId(int id);
	
	@Query("select h from Hire h where emp_emp_id=:id")
	public List<Hire> getHireEmp(@Param("id") int id);
	
}
