package com.inhouse.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InHouseServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
