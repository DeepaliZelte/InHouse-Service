import "./App.css";
import React, { Component } from "react";
import Adminlogincomponent from "./component/Adminlogincomponent";
import Homepagecomponent from "./component/Homepagecomponent";
import Customerlistcomponent from "./component/Customerlistcomponent";
import Employeehomepagecomponent from "./component/Employeehomepagecomponent";
import ForgotPass from "./component/ForgotPassword";
import Employeeregistration from "./component/Employeeregistration";
import Adminprofilecomponent from "./component/Adminprofilecomponent";
import CustomerReg from "./component/CustomerReg";
import CustHome from "./component/CustHome";
import { Footer } from "./component/Footer";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import AdminHome from "./component/AdminHome";
import Employeelist from "./component/Employee-list";
import CustNav from "./component/CustNav";
import Searchbycities from "./component/Searchbycities";
import BookedList from "./component/bookedlist";
import ViewOrders from "./component/viewOrders";
import Complaint from "./component/Complainpage";
import AdminComplain from "./component/adminComplain";
import ViewComplaints from "./component/ViewComplaint";
import SearchByProfession from "./component/SearchbyProfession";
import Adminnavbar3 from "./component/Adminnavbar3";
import ContactUs from "./component/ContactUs";
import EmpHome from "./component/EmpHome";
import EmpProfile from "./component/EmpProfile";
import CustProfile from "./component/CustProfile";
import AboutUs from "./component/AboutUs";
import { Navbar } from "./component/Navbar";

function App() {
  return (
    <>
 
 <Router>
        <div className="App">
          <Switch>
            <Route exact={true} path="/">
              <Homepagecomponent />
            </Route>
            <Route exact={true} path="/Homepagecomponent">
              <Homepagecomponent />
            </Route>
            <Route exact={true} path="/Adminlogincomponent">
              <Adminlogincomponent />
            </Route>
            <Route exact={true} path="/ForgotPass">
              <ForgotPass/>
            </Route>
            <Route exact={true} path="/Complaint">
            <Complaint/>
            </Route>
            <Route exact={true} path="/AdminHome">
              <AdminHome />
            </Route>
            <Route exact={true} path="/CustHome">
                <CustHome/>
                </Route>
               <Route exact={true} path="/CustProfile">
                 <CustProfile/>
                 </Route>
                <Route exact={true} path= "/EmpHome">
                  <EmpHome/>
                  </Route>
                <Route exact={true} path="/EmpProfile">
                  <EmpProfile/>
                  </Route>
            <Route exact={true} path="/Adminprofilecomponent">
              <Adminprofilecomponent />
            </Route>
            <Route exact={true} path="/Customerlistcomponent">
              <Customerlistcomponent />
            </Route>
            <Route exact={true} path="/Employeelist">
              <Employeelist />
            </Route>
            <Route exact={true} path="/AdminComplain">
              <AdminComplain/>
              </Route>
            <Route exact={true} path="/Employeeregistration">
              <Employeeregistration />
            </Route>
            <Route exact={true} path="/Employeehomepagecomponent">
              <Employeehomepagecomponent />
            </Route>
            <Route exact="true" path="/ViewOrders">
                   <ViewOrders/>
                 </Route>
            <Route exact={true} path="/CustNav">
              <CustNav/>   
              
              </Route>                
            <Route exact={true} path="/CustomerReg">
              <CustomerReg></CustomerReg>
            </Route>
            <Route exact={true} path="/Adminnavbar3">
              <Adminnavbar3/>
              </Route>
            
              <Route exact={true} path="/BookedList">
                <BookedList/>
                </Route>
                <Route exact={true} path="/Searchbycities">
                  <Searchbycities/>
                  </Route>
                <Route exact={true} path="/SearchByProfession">
                  <SearchByProfession/>
                </Route>
                <Route exact={true} path="/ViewComplaints">
                  <ViewComplaints/>
                 </Route> 
                 <Route exact={true} path="/AboutUs">
                   <AboutUs/>
                 </Route>
                 <Route exact={true} path="/ContactUs">
                 <ContactUs/>
                 </Route>
          </Switch>
          <Footer />
        </div>
      </Router>
   
    </>
  );
}

export default App;
