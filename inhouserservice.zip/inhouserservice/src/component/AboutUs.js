import 'bootstrap/dist/css/bootstrap.min.css';

import { Carousel } from "react-bootstrap";
import { Navbar } from "./Navbar";
import three from "./assets/images/chef.jpg";
import one from "./assets/images/driver.jpg";
import two from "./assets/images/event.jpg";
import four from "./assets/images/plumber.jpg";
import five from "./assets/images/painting.jpg";
import six from "./assets/images/customer.jpg";
function AboutUs() {

    return (
      <>
      <Navbar/>
      <div className="container-fluid mb-500" style={{height:"auto"}}>
		{<div className="row">
     
		<div className="col-md-5">
     
     <br/>

     <div className="row1  bmt-2" style={{height:"240px"}}>
     <img className="d-block w-100" src={six} alt="First image" style={{width:"auto",height:"250px"}}/> 
     </div>
     <br/>
     <div className="row1 bg-secondary mb-2" style={{height:"240px"}}>   
     <Carousel className="carousel">
      <Carousel.Item interval={1000}>
       <img className="d-block w-100" src={five} alt="First slide" style={{width:"auto",height:"240px"}}/> 
         </Carousel.Item> 

             <Carousel.Item interval={1000}>
                <img className="d-block w-100" src={four} alt="second slide" style={{width:"auto",height:"240px"}}/>
             </Carousel.Item>

             <Carousel.Item interval={1000}>
                <img className="d-block w-100" src={two} alt="Third slide" style={{width:"auto",height:"240px"}}/>
             </Carousel.Item>

             <Carousel.Item interval={1000}>
                 <img className="d-block w-100" src={three}  alt="fourth slide" style={{width:"auto",height:"240px"}}/>
             </Carousel.Item>

             <Carousel.Item>
                 <img className="d-block w-100" src={one} alt="fifth slide" style={{width:"auto",height:"240px"}}/>
             </Carousel.Item>
             </Carousel>

             

     </div>
  
    </div>
    <div className="col-md-7 d-flex flex-column justify-content-center align-items-start">
      
    <div className= "" style={{fontFamily:"Block"}}>
               <br></br>
               
      <br/>
      
      <h2>Who we are?</h2>
      <p>
      Inhouse Service is India's new online home servies platform. 
                 Our platform helps customers book reliable and high quality service -handymen,
                 painter and more-delivered by trained professionals conveniently at home.<br/> 
      </p>
       
      <h2>Our Mission</h2>
      <p>
      Our mission provides a platform that allows skilled and experienced professionals to 
               connect with users looking for specific services. All the professionals, though experienced and skilled,
                undergo intensive training modules before being allowed to list their services on the platform. Once on the platform, 
                our match-making algorithm identifies professionals who are closest to the users' requirements and available at the
                 requested time and date.
      </p>


      </div>

     
      <br/>
      </div>
      </div>}
      <br>
      </br>
      <br>
      </br>
      
      </div>
      </>
    );
}

export default AboutUs;