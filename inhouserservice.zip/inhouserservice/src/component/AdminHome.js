import React from "react";
import { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.css";
import Adminnavbar3 from "./Adminnavbar3";
import four from "./assets/4.jpg";

export default function AdminHome() {
  useEffect(() => {
    if (localStorage.getItem("role") === "null" || localStorage.getItem("role") != "admin") {
      window.location.href = "/Adminlogincomponent";
    }
  });
  return (
    <>
      <Adminnavbar3 />
      {/*<!-----------------------------------Slider---------------------------------->*/}

      <div
        id="carouselExampleSlidesOnly"
        class="carousel slide"
        data-bs-ride="carousel"
      >
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img
              src={four}
              class="d-block w-100"
              style={{ height: "650px" }}
              alt="..."
            />
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="..." />
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="..." />
          </div>
        </div>
      </div>

    </>
  );
}
