import React from "react";
import ReactCardFlip from 'react-card-flip';
import Component from 'react';
import { Navbar } from "./Navbar";

function ContactUs() {
    return (
      <div className=""  style={{backgroundImage:"url("+"https://i.pinimg.com/736x/bf/c5/9d/bfc59d92aba7e1da3cbbbe97bae5dd18.jpg"+")", backgroundRepeat: 'no-repeat ',backgroundSize: ' 100% 100% ',padding:'0'}}>
        <Navbar/>
        <div className="row " >
          <div className="col "><Flip/></div>
          <div className="col "><Flip1/></div>
          <div className="col "><Flip2/></div>
        </div>
      </div>
    );
  }


  function Heading(){
    return(
      <div className="" style={{padding:'50px'}}>
        <h1 className="d-flex justify-content-center align-items-center" style={{fontSize:'60px'}}><b>
        <em style={{}}>Contact Us</em></b> </h1>

      </div>
    );
  }



  class Flip extends React.Component {
    constructor() {
      super();
        this.state = {
        isFlipped: false
      };
      this.handleClick = this.handleClick.bind(this);
    }
  
    handleClick(e) {
      e.preventDefault();
      this.setState(prevState => ({ isFlipped: !prevState.isFlipped }));
    }

    

    
  
    render() {
      return (
          <div className=" d-flex justify-content-center align-items-center mb-3">
            <div className="mt-2 mb-2">        
            <ReactCardFlip isFlipped={this.state.isFlipped} flipDirection="vertical">
          <div >         
          <button className='front-flip-button' onClick={this.handleClick} style={{backgroundImage:"url("+"https://i.pinimg.com/favicons/d1cf990ac97d7684b763c74872b01750bea19f8da2b92f11cd70ec98.jpg?ad5786d2528871271500693a900c17fb"+")",
        fontSize:'0.875em',
        display:'block',
        left:'-60px',
        marginTop:'35px',
        padding:'40px',
        }}>
                    <div className="row middle" id="cspace"  style={{padding:'50px'}}>
                      <div className="col d-flex justify-content-center align-items-center ">
                          <i style={{fontSize:'80px'}} className="fa fa-phone fa-4x " ></i>
                      </div>
                      <div class="w-100"></div>
                      <div className="col d-flex justify-content-center align-items-center ">
                      <h5 className="" > Mobile Number </h5>
                      </div>
                      <div class="w-100"></div>
                  </div>
          
          </button>
            </div>
          <div>
            <button onClick={this.handleClick} style={{backgroundImage:"url("+"https://lh3.googleusercontent.com/b-D2xu102aBElUDgDVTdVS8B4gmlzlxLfyOCjzlQy7pPWm-aBoUR1udpuTWkTG8EboHjcORMQzfDxTiTCUF0PYMesQ=w640-h400-e365-rj-sc0x00ffffff"+")",
          fontSize:'0.875em',
          display:'block',
          left:'-60px',
          marginTop:'35px',
          padding:'40px'}}>
                  <div className="row middle" id="cspace"  style={{padding:'50px'}}>
                      <div className="col d-flex justify-content-center align-items-center ">
                          <i style={{fontSize:'80px'}} className="fa fa-phone fa-4x " ></i>
                      </div>
                      <div class="w-100"></div>
                      <div className="col d-flex justify-content-center align-items-center ">
                      <h5 className="" >+91-8698438659</h5>
                      </div>
                      <div class="w-100"></div>
                  </div>
          
            </button>
          </div>
        </ReactCardFlip>
        </div>
        </div>
      )
    }
  }
  class Flip1 extends React.Component {
    constructor() {
      super();
        this.state = {
        isFlipped: false
      };
      this.handleClick = this.handleClick.bind(this);
    }
  
    handleClick(e) {
      e.preventDefault();
      this.setState(prevState => ({ isFlipped: !prevState.isFlipped }));
    }
  
    render() {
      return (
          <div className="d-flex justify-content-center align-items-center mb-3">
            <div className="mt-2 mb-2">  
        <ReactCardFlip isFlipped={this.state.isFlipped} flipDirection="vertical">
          <div >
            <button onClick={this.handleClick} style={{backgroundImage:"url("+"https://i.pinimg.com/favicons/d1cf990ac97d7684b763c74872b01750bea19f8da2b92f11cd70ec98.jpg?ad5786d2528871271500693a900c17fb"+")",
          fontSize:'0.875em',
          display:'block',
          left:'-60px',
          marginTop:'35px',
          padding:'40px', }}>
                  <div className="row middle" id="cspace"  style={{padding:'50px'}}>
                      <div className="col d-flex justify-content-center align-items-center ">
                          <i style={{fontSize:'80px'}} className="fa fa-envelope-open fa-4x" ></i>
                      </div>
                      <div class="w-100"></div>
                      <div className="col d-flex justify-content-center align-items-center ">
                      <h5 className="" >Email Address</h5>
                      </div>
                      <div class="w-100"></div>
                  </div>
          
            </button>
            </div>
          <div>
            <button onClick={this.handleClick} style={{backgroundImage:"url("+"https://lh3.googleusercontent.com/b-D2xu102aBElUDgDVTdVS8B4gmlzlxLfyOCjzlQy7pPWm-aBoUR1udpuTWkTG8EboHjcORMQzfDxTiTCUF0PYMesQ=w640-h400-e365-rj-sc0x00ffffff"+")",
          fontSize:'0.875em',
          display:'block',
          left:'-60px',
          marginTop:'35px',
          padding:'40px'}}>
            
                  <div className="row middle" id="cspace"  style={{padding:'50px'}}>
                      <div className="col d-flex justify-content-center align-items-center ">
                          <i style={{fontSize:'80px'}} className="fa fa-envelope-open fa-4x" ></i>
                      </div>
                      <div class="w-100"></div>
                      <div className="col d-flex justify-content-center align-items-center ">
                      <h6 className="" >Inhouseservices7@gmail.com</h6>
                      </div>
                      <div class="w-100"></div>
                  </div>
          
            </button>
          </div>
        </ReactCardFlip>
        </div>
        </div>
      )
    }
  }
  class Flip2 extends React.Component {
    constructor() {
      super();
        this.state = {
        isFlipped: false
      };
      this.handleClick = this.handleClick.bind(this);
    }
  
    handleClick(e) {
      e.preventDefault();
      this.setState(prevState => ({ isFlipped: !prevState.isFlipped }));
    }
  
    render() {
      return (
          <div className=" d-flex justify-content-center align-items-center mb-3"  >
        <div className="mt-2 mb-2">  
        <ReactCardFlip isFlipped={this.state.isFlipped} flipDirection="vertical">
          <div>
           
            <button onClick={this.handleClick} style={{backgroundImage:"url("+"https://i.pinimg.com/favicons/d1cf990ac97d7684b763c74872b01750bea19f8da2b92f11cd70ec98.jpg?ad5786d2528871271500693a900c17fb"+")",
          fontSize:'0.875em',
          display:'block',
          left:'-60px',
          marginTop:'35px',
          padding:'40px',
          }}>
                  <div className="row middle" id="cspace" style={{padding:'50px'}}>
                      <div className="col d-flex justify-content-center align-items-center ">
                      <i style={{fontSize:'80px'}} class="fa fa-users" aria-hidden="true"></i>
                      </div>
                      <div class="w-100"></div>
                      <div className="col d-flex justify-content-center align-items-center ">
                      <h5 className="" >Administration Team</h5>
                      </div>
                      <div class="w-100"></div>
                  </div>
          
            </button>
            </div>
          <div>
           
            <button onClick={this.handleClick} style={{backgroundImage:"url("+"https://lh3.googleusercontent.com/b-D2xu102aBElUDgDVTdVS8B4gmlzlxLfyOCjzlQy7pPWm-aBoUR1udpuTWkTG8EboHjcORMQzfDxTiTCUF0PYMesQ=w640-h400-e365-rj-sc0x00ffffff"+")",
          fontSize:'0.875em',
          display:'block',
          left:'-60px',
          marginTop:'35px',
          padding:'40px', backgroundRepeat: 'no-repeat ',backgroundSize: ' 100% 100% '}}>
          
                  <div className="row middle" id="cspace" style={{padding:'10px'}}>
                      <div className="col d-flex justify-content-center align-items-center ">
                          <i style={{fontSize:'60px'}} class="fa fa-users" aria-hidden="true"></i>
                      </div>
                      <div class="w-100"></div>
                      <div className="col d-flex justify-content-center align-items-center ">

                     <p> <h6 className="" >Deepali Zelte</h6>
                      <h6 className="" >Pooja Wayal</h6>
                     </p>
                      </div>
                      <div class="w-100"></div>
                  </div>
          
            </button>
          </div>
        </ReactCardFlip>
        </div>
        </div>
      )
    }
  }

// // previous background Image
// //   {backgroundImage:"URL('https://images.wallpaperscraft.com/image/spruce_branch_needles_200732_1600x1200.jpg')"}
  
// function FullPage(){
//     const style8={
//         'background':'#7a7aff',
//     }
//       return(
//         <div className=""  style={style8}>
//                 <div>
//                     <ContactUsHeading/>
//                 </div>
//                 <div className="row">
//                 <div className="col d-flex justify-content-center align-items-center">
//                     {/* <Second/> */}
//                     <Carousels/>
//                 </div>
                    
//                 <div className="col d-flex justify-content-center align-items-center"> 
//                     <First/>
//                 </div>
//             </div>
//     </div>
//       );
//   }

// //   https://images.wallpaperscraft.com/image/spruce_branch_needles_200732_1600x1200.jpg
// function ContactUsHeading(){
//     const styles1 = {
//         'color':'rgb(255, 255, 255)',
//          'text-align': 'center',
//          'padding': '20px',
//          'textDecorationLine': 'underline',
//         }
//     return(
//         <div className="d-flex justify-content-center align-items-center middle" >
//             {/* <h1 className="fw-bolder" id="cspace1" style={styles1} > */}
//               <h1>
//                 <b><span style={{color:'red'}}> Contact Us</span></b>
//             </h1>
//         </div>

//     );
// }

// function First(){
//     const iconstyles = {
//         'height':'40px',
//     }
//     const styles = {
     
//     }
//     const style7 = {
//         'font-size': '30%', 
//     }
//     const styles1 = {
//         'color':'rgb(255, 255, 255)',
//          'text-align': 'center',
//          'padding': '30px',
//     }
//     const styles4={
//         'color': 'rgb(160, 160, 168)',
//     }
//     const style6={
//         'color':'white',
//         'font-size': '100%',
//     }
//     return(
//         <div className=" container-fluid"  >
//         <div className="row border border-1 rounded mr-1 ml-1 mb-1 mt-1" style={{padding:"10px"}}>
//             <div className="col border border-dark   " style={styles4}>
//                 <div className="row middle" id="cspace" style={styles}>
//                     <div className="col d-flex justify-content-center align-items-center ">
//                         <i className="fa fa-phone fa-4x " style={{iconstyles}}></i>
//                     </div>
//                     <div class="w-100"></div>
//                     <div className="col d-flex justify-content-center align-items-center ">
//                     <h5 className="" style={style6}> By Phone </h5>
//                     </div>
//                     <div class="w-100"></div>
//                     <div className="col d-flex justify-content-center align-items-center" >
//                         <h6 style={style6}>Mobile No</h6>
//                     </div>
//                     <div class="w-100"></div>
//                     <div className="col d-flex justify-content-center align-items-center" style={style6}>
//                         7071972711
//                     </div>
//                     <div class="w-100"></div>
//                 </div>
//             </div>
//             <div class="w-100"></div>
//             <div className="col   border border-dark " style={styles4}>
//                 <div className="row middle" id="cspace" style={styles}>
//                         <div className="col d-flex justify-content-center align-items-center ">
//                             <i className="fa fa-envelope-open fa-4x" style={{iconstyles}}></i>
//                         </div>
//                         <div class="w-100"></div>
//                         <div className="col d-flex justify-content-center align-items-center ">
//                             <h5 className="" style={style6}> By Email </h5>
//                         </div>
//                         <div class="w-100"></div>
//                         <div className="col d-flex justify-content-center align-items-center">
//                                 <h6 style={style6}>Email Address</h6> 
//                         </div>
//                         <div class="w-100"></div>
//                         <div className="col d-flex justify-content-center align-items-center">
//                             <p style={style6}>YEAHHHHHHH@GMAIL.COM</p>
//                         </div>
//                         <div class="w-100"></div>
                    
//                 </div>
//             </div>
//             <div class="w-100"></div>
//             <div className="col  border border-dark " style={styles4}>
//                 <div className="row middle" id="cspace" style={styles}>
//                             <div className="col d-flex justify-content-center align-items-center ">
//                                 <i className="fa fa-home fa-4x" style={{iconstyles}}></i>
//                             </div>
//                             <div class="w-100"></div>
//                             <div className="col d-flex justify-content-center align-items-center">
//                             <h5 className="" style={style6}> Write US Here </h5>
//                             </div>
//                             <div class="w-100"></div>
//                             <div className="col d-flex justify-content-center align-items-center">
//                                 <h6 style={style6}>Postal Address</h6>
//                             </div>
//                             <div class="w-100"></div>
//                             <div className="col d-flex justify-content-center align-items-center">
//                                 <p style={style6}>EDAC 2020,MUMBAI</p>
//                             </div>
//                             <div class="w-100"></div>
//                 </div>
//             </div>
//         </div>       
//     </div>   
//       );
// }

// function Second(){
//     const styles3={
//         //  'color': 'blue',
//         // 'backgroundImage':"URL(''https://pngtree.com/free-backgrounds')"
//         // backgroundImage:"URL('https://png.pngtree.com/thumb_back/fw800/back_pic/00/04/53/9556248b4747950.png')"
//     }
//     return(
//         <div className="container-fluid" style={styles3} >
//             <div className="row">
//                 <div className="col-6 d-flex justify-content-center align-items-center" style={{padding:"20px"}}>
//                     <h3 className="fw-bolder"><b>Contact <span  id="contactusheader" > With Us </span></b></h3>
//                 </div>
//                 <div className="col-6 d-flex justify-content-center align-items-center" style={{padding:"20px"}}>
//                     {/* BASBJCBSJH */}
//                 </div>
//             </div>
            
//         </div>
//     );
// }

// function Carousels(){
//     const style5={
//         'height':'320px',
//         'width':'75%',
//     }
//     return(
//         <div className="container-fluid row" style={style5} >
//     <Carousel className="col-12">
//         <Carousel.Item interval={1000}>
//             <img
//             className="d-block w-100"
//             src="https://daily.jstor.org/wp-content/uploads/2020/09/the_linguistic_evolution_of_taylor_swift_1050x700.jpg"
//             height="250"
//             alt="First slide"
//             />
//             <Carousel.Caption>
//             {/* <h3>First slide label</h3> */}
//             {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
//             </Carousel.Caption>
//         </Carousel.Item>
//         <Carousel.Item interval={500}>
//             <img
//             className="d-block w-100"
//             src="https://daily.jstor.org/wp-content/uploads/2020/09/the_linguistic_evolution_of_taylor_swift_1050x700.jpg"
//             height="250"
//             alt="Second slide"
//             />
//             <Carousel.Caption>
//             {/* <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
//             </Carousel.Caption>
//         </Carousel.Item>
//         <Carousel.Item>
//             <img
//             className="d-block w-100"
//             src="https://daily.jstor.org/wp-content/uploads/2020/09/the_linguistic_evolution_of_taylor_swift_1050x700.jpg"
//             height="250"
//             alt="Third slide"
//             />
//             <Carousel.Caption>
//             {/* <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p> */}
//             </Carousel.Caption>
//         </Carousel.Item>
//         </Carousel>
//     </div>
//     );
// }




  export default ContactUs;