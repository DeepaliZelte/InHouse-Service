import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import four from "./assets/pimage/carpainter.webp";
import one from "./assets/pimage/driver.webp";
import two from "./assets/pimage/eventplan.webp";
import three from "./assets/pimage/chef1.jpg";
import CustNav from "./CustNav";
import { Carousel } from 'react-bootstrap';
import { useEffect} from "react";
export default function CustHome() {
  useEffect(() => {

    if (localStorage.getItem("role") === "null" || localStorage.getItem("role") != "customer") {
      window.location.href = "/Adminlogincomponent";
    }
  });
  return (
    <>
      <CustNav />
      {/*<!-----------------------------------Slider---------------------------------->*/}

      <div>
        <div className='container-fluid mt-3 mb-3' >

          <div className="row">
            <div className="col-12" >
              <Carousel >

                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src={one}
                    alt="First slide" style={{ height: "600px" }}
                  />
                  <Carousel.Caption>
                    <h3>Welcome To InHouse Service</h3>
                    <p>We Provide Best & Relible Services.</p>
                  </Carousel.Caption>
                </Carousel.Item>

                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src={two}
                    alt="Second slide" style={{ height: "600px" }}
                  />

                  <Carousel.Caption>
                    <b> <h2 style={{ color: 'black' }}>Welcome To InHouse Service</h2>
                      <p style={{ color: 'black' }}>We Provide Best & Relible Services.</p></b>
                  </Carousel.Caption>
                </Carousel.Item>

                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src={four}
                    alt="Second slide" style={{ height: "600px" }}
                  />

                  <Carousel.Caption>
                    <b> <h2 style={{ color: 'black' }}>Welcome To InHouse Service</h2>
                      <p style={{ color: 'black' }}>We Provide Best & Relible Services.</p></b>
                  </Carousel.Caption>
                </Carousel.Item>


                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src={three}
                    alt="Third slide" style={{ height: "600px" }}
                  />
                  <Carousel.Caption>
                    <b> <h2 style={{ color: 'black' }}>Welcome To InHouse Service</h2>
                      <p style={{ color: 'black' }}>We Provide Best & Relible Services.</p></b>
                  </Carousel.Caption>
                </Carousel.Item>

              </Carousel>
            </div>
          </div>
        </div>
      </div>

      <div
        id="carouselExampleSlidesOnly"
        class="carousel slide mt-3 mb-3"
        data-bs-ride="carousel"
      >
        <div class="carousel-inner">


          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="..." />
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="..." />
          </div>
        </div>
      </div>

    </>
  );
}
