import React from "react";
import "bootstrap/dist/css/bootstrap.css";

import "./employee-profile.component.css";

import { useState } from "react";
import axios from "axios";
import "./employee-registration.component.css";

import { Navbar } from "./Navbar";
import swal from "sweetalert";

function Employeeregistration() {
  const [custName, setCustName] = useState("");
  const [custGender, setCustGender] = useState("Male");
  const [custAddress, setCustAddress] = useState("");
  const [custEmail, setCustEmail] = useState("");
  const [custPassword, setCustPassword] = useState("");
  const [conPassword, setConPassword] = useState("");
  const [custContact, setCustContact] = useState("");
  const custStatus = "active";

  const regex =
    /^([a-zA-Z0-9_\.\-\ ])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  const regex1 = /^([a-zA-Z\ ])+$/;
  const regex2 = /^[6-9]{1}[0-9]{9}$/;

  const handleForm = (e) => {
    e.preventDefault();
    if (
      custName === "" ||
      custAddress === "" ||
      custEmail === "" ||
      custPassword === "" ||
      custContact === ""
    ) {
      swal("error", "please enter details", "error");
    } else if (!regex1.test(custName)) {
      swal("Error!", "Please Enter valid Name", "error");
    } else if (!regex.test(custEmail)) {
      swal("Error!", "Please Enter Valid Email Address", "error");
    } else if (custPassword.length < 6 || custPassword.length > 10) {
      swal("Error!", "Password length is min 6 and max length is 10", "error");
    } else if (
      !regex2.test(custContact) ||
      custContact.length < 10 ||
      custContact.length > 10
    ) {
      swal("Error!!", "Please Enter valid mobile number", "error");
    } else if (conPassword != custPassword) {
      swal("Error!", "Password does not match", "error");
    } else {
      addCustomer();
    }
  };

  const addCustomer = async () => {
    const cust = {
      custName: custName,
      custGender: custGender,
      custAddress: custAddress,
      custEmail: custEmail,
      custPassword: custPassword,
      custContact: custContact,
      custStatus: custStatus,
    };
    const resp = await axios.post("http://localhost:8081/addCustomer", cust);
    swal("success", " Your Registration Completed Successful", "success");
    window.location.href="/Adminlogincomponent";
  };

  return (
    <>
      <Navbar />
      <div class="container mt-4 mb-4" style={{border:'2px solid black'}}>
        <div class="row" style={{ justifyContent: "left" }}>
          <div class="col-2 "></div>
          <div class="col-8" style={{ backgroundcolor: "black" }}>
            <div class="row">
              <div class="col-2"></div>
              <div class="col-md-8">
                <div class="do">
                  <form class="form-group" onsubmit=" return  callvalidation()">
                    <div class="inside-form mt-3" style={{ color: "dark" }}>
                      <center>
                        <h2>
                          <b>Customer Registration</b>
                        </h2>
                      </center>
                    </div>
                    <div class="form-group ">
                      <label id="sty"
                        style={{ fontSize: "14px", backgroundColor: "#99ebff" }}
                      >
                        Personal Details
                      </label>
                    </div>
                    <div class="form-group ">
                      <label for="" id="sty">
                        Full Name <span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="fullName"
                        name="setCustName"
                        placeholder="enter your name"
                        onChange={(e) => {
                          setCustName(e.target.value);
                        }}
                      />
                      <span id="errormsg"></span>
                    </div>
                    <div class="form-group ">
                      <label for="" id="sty">
                        Gender<span>*</span>
                      </label>
                      <select
                        class="form-control"
                        name="custGender"
                        id="gender"
                        onChange={(e) => {
                          setCustGender(e.target.value);
                        }}
                      >
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                   
                    <div class="form-group ">
                      <label for="" id="sty">
                        Contact No<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="contactNo"
                        name="custContact"
                        placeholder="enter your ContactNo"
                        onChange={(e) => {
                          setCustContact(e.target.value);
                        }}
                      />
                      <span id="errormsg1"></span>
                    </div>

                    <div class="form-group ">
                      <label for="" id="sty">
                        Address<span>*</span>
                      </label>
                      <textarea
                        class="form-control"
                        rows="1"
                        id="address"
                        name="custAddress"
                        placeholder="enter your Address"
                        onChange={(e) => {
                          setCustAddress(e.target.value);
                        }}
                      ></textarea>
                    </div>
                    <br />

                   
                    <div class="col info-row">
                      <label id="sty"
                        style={{ fontSize: "14px", backgroundColor: "#99ebff" }}
                      >
                        Registration Info
                      </label>
                    </div>

                    <div class="form-group ">
                      <label for="email" id="sty">
                        Email Id:<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="email"
                        name="custEmail"
                       
                        placeholder="enter your Email"
                        onChange={(e) => {
                          setCustEmail(e.target.value);
                        }}
                      />
                     
                    </div>

                    <div class="form-group ">
                      <label for="password" id="sty">
                        Password:<span>*</span>
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="password"
                        name="custPassword"
                       
                        placeholder="enter Password"
                        onChange={(e) => {
                          setCustPassword(e.target.value);
                        }}
                      />
                     
                    </div>
                    <div class="form-group ">
                      <label for="confirmPassword" id="sty">
                        Confirm Password:
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="confirmPassword"
                        onChange={(e) => {
                          setConPassword(e.target.value);
                        }}
                       
                        placeholder="confirm Password"
                      />
                     
                    </div>

                    <div class="form-group ">
                      <button
                        class="btn btn-success mt-2"
                        type="submit"
                        onClick={handleForm}
                       
                      >
                        Submit
                      </button>
                      <div id="sty">
                        <label>already have account ? </label>
                        <a href="Adminlogincomponent" style={{color:"black"}}>Login Here</a>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-2"></div>
          </div>
        </div>
      </div>
    </>

  );
}
export default Employeeregistration;
