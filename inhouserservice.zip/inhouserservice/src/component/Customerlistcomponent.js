import { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./customer-list.component.css";
import axios from "axios";
import Adminnavbar3 from "./Adminnavbar3";

function Customerlistcomponent() {
  const [CustomerList, setCustomerList] = useState([]);
  useEffect(() => {
    if(localStorage.getItem("role")==="null" || localStorage.getItem("role")!="admin" )
{
  window.location.href="/Adminlogincomponent";
}
    getUserList();
  }, []);

  const getUserList = async () => {
    console.log("in list");
    const res = await axios.get("http://localhost:8081/customerList");
    setCustomerList(res.data);
  };

  const updateStatus = async (id) => {
    const cust = { custId: id };
    const res = await axios.post(
      "http://localhost:8081/updatecuststatus",
      cust
    );
    window.location.href = "/Customerlistcomponent";
  };
  return (
    <>
      <Adminnavbar3 />
     

<div class="m-5">

<div class="row">
        

          {CustomerList.map((item) => {
            return (
              <div class="card m-auto mb-3 card-text d-flex" style={{width:"450px"}}>
              <div class=" card text-dark" style={{color:'black'}}>
              
            <th style={{fontSize:'30px',color:"#8A2BE2"}}>{item.custName}</th><hr/>       
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Address : {item.custAddress}</th>     
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Contact :{item.custContact}</th>     

            <th style={{fontSize:'18px',fontWeight:'bold'}}>Email : {item.custEmail}</th>   

            <th style={{fontSize:'18px',fontWeight:'bold'}}>Status : {item.custStatus}</th> 

                <center class="card-footer">
                  <button
                    class="btn btn-primary"
                    onClick={() => {
                      updateStatus(item.custId);
                    }}
                  >
                    Block
                  </button>
                </center>
              
              </div>
            </div>
            );
          })}
          
        </div>
     </div>
     </>
  );
}

export default Customerlistcomponent;
