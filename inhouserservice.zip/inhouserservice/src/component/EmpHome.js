import {React,useEffect} from "react";
import "bootstrap/dist/css/bootstrap.css";
import Employeehomepagecomponent from "./Employeehomepagecomponent";
import four from "./assets/pimage/4.jpg";
import one from "./assets/pimage/3.jpg";
import two from "./assets/pimage/5.jpg";
import three from "./assets/pimage/plumber.jpg";
import { Carousel } from 'react-bootstrap';
export default function EmpHome() {

    useEffect(() => {
        if(localStorage.getItem("role")==="null" || localStorage.getItem("role")!="employee" )
    {
      window.location.href="/Adminlogincomponent";
    }
         
      });

  return (
    <>
      <Employeehomepagecomponent/>
      {/*<!-----------------------------------Slider---------------------------------->*/}
      <div>
                <div className='container-fluid mt-4 mb-4' >
                    
                    <div className="row">
                        <div className="col-12" >
                            <Carousel >

                                <Carousel.Item>
                                    <img
                                        className="d-block w-100"
                                        src={one}
                                        alt="First slide"style={{height:"600px"}}
                                    />
                                    <Carousel.Caption>
                                    <b> <h2 style={{color:'black'}}>Welcome To InHouse Service</h2>
                                        <p style={{color:'black'}}>We Provide Best & Relible Services.</p></b>
                                    </Carousel.Caption>
                                </Carousel.Item>

                                <Carousel.Item>
                                    <img
                                        className="d-block w-100"
                                        src={two}
                                        alt="Second slide"style={{height:"600px"}}
                                    />

                                    <Carousel.Caption>
                                    <b> <h2 style={{color:'black'}}>Welcome To InHouse Service</h2>
                                        <p style={{color:'black'}}>We Provide Best & Relible Services.</p></b>
                                    </Carousel.Caption>
                                </Carousel.Item>

                                <Carousel.Item>
                                    <img
                                        className="d-block w-100"
                                        src={four}
                                        alt="Second slide"style={{height:"600px"}}
                                    />

                                    <Carousel.Caption>
                                       <b> <h2 style={{color:'black'}}>Welcome To InHouse Service</h2>
                                        <p style={{color:'black'}}>We Provide Best & Relible Services.</p></b>
                                    </Carousel.Caption>
                                </Carousel.Item>


                                <Carousel.Item>
                                    <img
                                        className="d-block w-100"
                                        src={three}
                                        alt="Third slide"style={{height:"600px"}}
                                    />
                                    <Carousel.Caption>
                                    <b> <h2 style={{color:'black'}}>Welcome To InHouse Service</h2>
                                        <p style={{color:'black'}}>We Provide Best & Relible Services.</p></b>
                                    </Carousel.Caption>
                                </Carousel.Item>

                            </Carousel>
                        </div>
                    </div>
                </div>
            </div>



      <div
        id="carouselExampleSlidesOnly"
        class="carousel slide"
        data-bs-ride="carousel"
      >
       
          
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="..." />
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="..." />
          </div>
        </div>
     
    </>
  );
}
