import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./employee-list.component.css";
import axios from "axios";
import { useState, useEffect } from "react";
import Adminnavbar3 from "./Adminnavbar3";

function Employeelist() {
  const [employeelist, setEmployeeList] = useState([]);

  useEffect(() => {
    if (localStorage.getItem("role") === "null" || localStorage.getItem("role") != "admin") {
      window.location.href = "/Adminlogincomponent";
    }
    getEmpList();
  }, []);

  const getEmpList = async () => {
    console.log("in list");
    const res = await axios.get("http://localhost:8081/employeeList");
    setEmployeeList(res.data);
  };

  const updateStatus = async (id) => {
    const emp = { empId: id };
    const res = await axios.post("http://localhost:8081/updateempstatus", emp);
    window.location.href = "/Employeelist";
  };

  return (
    <>
      <Adminnavbar3 />

      <div class="m-5">

        <div class="row">

          {employeelist.map((item) => {
            return (
              <div class="card m-auto mb-3 card-text d-flex" style={{ width: "450px" }}>
                <div class=" card text-dark" style={{ color: 'black' }}>
                  <th style={{fontSize:'30px',color:"#8A2BE2"}}> {item.empName}</th><hr/>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>City :{item.empCity}</th>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>Contact :{item.empContact}</th>
                  <th style={{fontSize:'22px',fontWeight:'bold'}}>Profession :{item.profession}</th>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>Exp(Yrs) : {item.empExperience}</th>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>Rate/hr :{item.empRatePerHr}</th>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>Email : {item.empEmail}</th>

                  <th style={{fontSize:'18px',fontWeight:'bold'}}>Status : {item.empStatus}</th>
                  <center class="card-footer">
                    <button
                      class=" btn btn-primary"
                      onClick={() => {
                        updateStatus(item.empId);
                      }}
                    >
                      Block
                    </button>
                  </center>
                </div>
              </div>
            );
          })}
        </div>
      </div>


    </>

  );
}

export default Employeelist;
