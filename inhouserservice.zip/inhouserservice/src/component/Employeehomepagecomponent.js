import React from 'react';
import "bootstrap/dist/css/bootstrap.css";
import { useState } from "react";
import { NavLink } from "react-router-dom";
import "./NavBar.css";;

          
function Employeehomepagecomponent(){
    const logout = () => {
        localStorage.setItem("role",null);

        window.location.href = "/Adminlogincomponent";
      };

      const [click, setClick] = useState(false);

      const handleClick = () => setClick(!click);
        return(

            <>
            <nav className="navbar">

<div className="nav-container">

 <ul className={click ? "nav-menu active" : "nav-menu"}>
  <li>
  <a class="navbar-brand" href="EmpHome" style={{color:"orange"}}>Inhouse Services</a>
    </li>
    <li className="nav-item">
      <NavLink
        exact
        to="/EmpHome"
        activeClassName="active"
        className="nav-links"
        onClick={handleClick}
      >
        Home
      </NavLink>
    </li>
    <li className="nav-item">
      <NavLink
        exact
        to="/EmpProfile"
        activeClassName="active"
        className="nav-links"
        onClick={handleClick}
      >
        Profile
      </NavLink>
    </li>
    
    <li className="nav-item">
      <NavLink
        exact
        to="/viewOrders"
        activeClassName="active"
        className="nav-links"
        onClick={handleClick}
      >View Order Request
      </NavLink>
    </li>
    <li className="nav-item">
      <NavLink
        exact
        to="/Adminlogincomponent"
        activeClassName="active"
        className="nav-links"
        onClick={logout}
      >
        Logout
      </NavLink>
    </li>
  </ul>
  <div className="nav-icon" onClick={handleClick}>
    <i className={click ? "fas fa-times" : "fas fa-bars"}></i>
  </div>
</div>
</nav>
            </>

           
        );
    
}
export default Employeehomepagecomponent;