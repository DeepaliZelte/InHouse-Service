import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./employee-profile.component.css";
import { useState } from "react";
import axios from "axios";
import "./employee-registration.component.css";
import { Navbar } from "./Navbar";
import swal from "sweetalert";

function Employeeregistration() {
  const [empName, setEmpName] = useState("");
  const [empAdharno, setEmpAdharno] = useState("");
  const [empGender, setEmpGender] = useState("Male");
  const [empAddress, setEmpAddress] = useState("");
  const [empCity, setEmpCity] = useState("");
  const [profession, setProfession] = useState("");
  const [empExperience, setEmpExperience] = useState("");
  const [empRatePerHr, setEmpRatePerHr] = useState("");
  const [empEmail, setEmpEmail] = useState("");
  const [empPassword, setEmpPassword] = useState("");
  const [conPassword, setConPassword] = useState("");

  const [empContact, setEmpContact] = useState("");
  const empStatus = "active";

  const regex =
    /^([a-zA-Z0-9_\.\-\ ])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  const regex1 = /^([a-zA-Z\ ])+$/;
  const regex2 = /^[6-9]{1}[0-9]{9}$/;

  const handleForm = (e) => {
    e.preventDefault();
    if (
      empName === "" ||
      empAdharno === "" ||
      empAddress === "" ||
      empCity === "" ||
      profession === "" ||
      empExperience === "" ||
      empRatePerHr === "" ||
      empEmail === "" ||
      empPassword === ""
    ) {
      swal("error", "please enter details", "error");
    } else if (!regex1.test(empName)) {
      swal("Error!", "Please Enter valid Name", "error");
    } else if (!regex.test(empEmail)) {
      swal("Error!", "Please Enter Valid Email Address", "error");
    } else if (empPassword.length < 6 || empPassword.length > 10) {
      swal("Error!", "Password length is min 6 and max length is 10", "error");
    } else if (empAdharno.length < 12 || empAdharno.length > 12) {
      swal("Error!", "Aadhar number length must be 12", "error");
    } else if (
      !regex2.test(empContact) ||
      empContact.length < 10 ||
      empContact.length > 10
    ) {
      swal("Error!!", "Please Enter valid mobile number", "error");
    } else if (conPassword != empPassword) {
      swal("Error!", "Password does not match", "error");
    } else {
      addEmployee();
    }
  };

  const addEmployee = async () => {
    console.log(profession);
    const emp = {
      empName: empName,
      empAdharno: empAdharno,
      empGender: empGender,
      empAddress: empAddress,
      empCity: empCity,
      profession: profession,
      empExperience: empExperience,
      empRatePerHr: empRatePerHr,
      empEmail: empEmail,
      empPassword: empPassword,
      empStatus: empStatus,
      empContact: empContact,
    };
    const resp = await axios.post("http://localhost:8081/addEmployee", emp);
    swal("success", " Your Registration Completed Successful", "success");
    window.location.href="/Adminlogincomponent";
  };

  return (
    <>
      <Navbar />

      <div class="container mt-4 mb-4" style={{border:"2px solid black"}}>
        <div class="row" >
          <div class="col-2 "></div>
          <div class="col-8" >
            <div class="row">
              <div class="col-2"></div>
              <div class="col-md-8">
                <div class="do">
                  <form class="form-group" onsubmit=" return  callvalidation()">
                    <div class="inside-form mt-3" style={{ color: "dark" }}>
                      <center>
                        <h2>
                          <b>Employee Registration</b>
                        </h2>
                      </center>
                    </div>
                    <div class="form-group ">
                      <label id="sty"
                        style={{ fontSize: "14px", backgroundColor: "#99ebff" }}
                      >
                        Personal Details
                      </label>
                    </div>
                    <div class="form-group ">
                      <label for="" id="sty">
                        Full Name <span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="fullName"
                        name="employeeName"
                        placeholder="enter your name"
                        onChange={(e) => {
                          setEmpName(e.target.value);
                        }}
                      />
                      <span id="errormsg"></span>
                    </div>
                    <div class="form-group ">
                      <label for="" id="sty">
                        Gender<span>*</span>
                      </label>
                      <select
                        class="form-control"
                        name="employeeGender"
                        id="gender"
                        onChange={(e) => {
                          setEmpGender(e.target.value);
                        }}
                      >
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  
                    <div class="form-group ">
                      <label for="" id="sty">
                        Contact No<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="contactNo"
                        name="employeeContact"
                        placeholder="enter your ContactNo"
                        onChange={(e) => {
                          setEmpContact(e.target.value);
                        }}
                      />
                      <span id="errormsg1"></span>
                    </div>
                    <div class="form-group ">
                      <label for="" id="sty">
                        Addhar Number<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="AddharNo"
                        name="employeeAadharNumber"
                        placeholder="enter your AadharNumber"
                        onChange={(e) => {
                          setEmpAdharno(e.target.value);
                        }}
                      />
                      <span id="errormsg2"></span>
                    </div>
                    <div class="form-group ">
                      <label for="" id="sty">
                        Address<span>*</span>
                      </label>
                      <textarea
                        class="form-control"
                        rows="1"
                        id="address"
                        name="employeeAddress"
                        placeholder="enter your Address"
                        onChange={(e) => {
                          setEmpAddress(e.target.value);
                        }}
                      ></textarea>
                    </div>
                    <br />

                    <div class="form-group ">
                      <label id="sty"
                        style={{ fontSize: "14px", backgroundColor: "#99ebff" }}
                      >
                        Work Info
                      </label>
                    </div>

                    <div class="form-group ">
                      <label for="" id="sty">
                        Profession<span>*</span>
                      </label>
                      <select
                        class="form-control"
                        name="professionId"
                        id="profession"
                        onChange={(e) => {
                          setProfession(e.target.value);
                        }}
                      >
                        <option value="Driver">Driver</option>
                        <option value="Plumber">Plumber</option>
                        <option value="Painter">Painter</option>
                        <option value="Event Planner">Event Planner</option>
                        <option value="Chef">Chef</option>
                        
                      </select>
                    </div>

                    <div class="form-group ">
                      <label for="" id="sty">
                        Experiance<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="experience"
                        name="employeeExperiance"
                        onChange={(e) => {
                          setEmpExperience(e.target.value);
                        }}
                        placeholder="enter your Experiance"
                      />
                    </div>

                    <div class="form-group">
                      <label for="" id="sty">
                        Rate/Hour(Rs)<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="rate"
                        name="employeeRate"
                        placeholder="enter your charges"
                        onChange={(e) => {
                          setEmpRatePerHr(e.target.value);
                        }}
                      />
                    </div>

                    <div class="form-group ">
                      <label for="" id="sty">
                        City/Area<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="city"
                        name="employeeCity"
                        placeholder="enter your City"
                        onChange={(e) => {
                          setEmpCity(e.target.value);
                        }}
                      />
                    </div>

                    <div class="col info-row">
                      <label class="text" id="sty"
                        style={{ fontSize: "14px", backgroundColor: "#99ebff" }}
                      >
                        Registration Info
                      </label>
                    </div>

                    <div class="form-group ">
                      <label for="email" id="sty" style={{ fontSize: "15px" }}>
                        Email Id:<span>*</span>
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="email"
                        name="employeeEmail"
                        style={{ fontSize: "15px" }}
                        placeholder="enter your Email"
                        onChange={(e) => {
                          setEmpEmail(e.target.value);
                        }}
                      />
                      <span id="errormsg3"></span>
                    </div>

                    <div class="form-group ">
                      <label for="password" id="sty" style={{ fontSize: "15px" }}>
                        Password:<span>*</span>
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="password"
                        name="employeePassword"
                        style={{ fontSize: "15px" }}
                        placeholder="enter Password"
                        onChange={(e) => {
                          setEmpPassword(e.target.value);
                        }}
                      />
                      <span id="errormsg4"></span>
                      <span id="errormsg4"></span>
                    </div>
                    <div class="form-group ">
                      <label for="confirmPassword" id="sty"  style={{ fontSize: "15px" }}>
                        Confirm Password:<span>*</span>
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="confirmPassword"
                        onChange={(e) => {
                          setConPassword(e.target.value);
                        }}
                        style={{ fontSize: "15px" }}
                        placeholder="confirm Password"
                      />
                      <span id="errormsg5"></span>
                    </div>

                    <div class="form-group ">
                      <button
                        class="btn btn-success mt-2"
                        type="submit"
                        onClick={handleForm}
                        style={{ fontSize: "15px" }}
                      >
                        Submit
                      </button>
                      <div id="sty">
                        <label>already have account ? </label>
                        <a href="Adminlogincomponent" style={{color:"black"}}>Login Here</a>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>

  );
}
export default Employeeregistration;
