import { Link } from "react-router-dom";
import 'font-awesome/css/font-awesome.min.css';
export function Footer() {
  return (



<footer class=" Footer stick-bottom  text-center text-white " >

<div class="container-fluid p-4 pb-0">
 
  <section class="mb-4">
 
    <a class="btn btn-outline-light btn-floating m-1" href="https://www.facebook.com/login.php" type="button"
      ><i class="fa fa-facebook-f"></i
    ></a>

    <a class="btn btn-outline-light btn-floating m-1" href="https://twitter.com/login/" type="button"
      ><i class="fa fa-twitter"></i
    ></a>

    <a class="btn btn-outline-light btn-floating m-1" href="https://myaccount.google.com/" Type="button"
      ><i class="fa fa-google"></i
    ></a>

    <a class="btn btn-outline-light btn-floating m-1" href="https://www.instagram.com/accounts/login/" type="button"
      ><i class="fa fa-instagram"></i
    ></a>

    <a class="btn btn-outline-light btn-floating m-1" href="https://www.linkedin.com/uas/login" type="button"
      ><i class="fa fa-linkedin"></i
    ></a>

    
    <a class="btn btn-outline-light btn-floating m-1" href="https://github.com/login" type="button"
      ><i class="fa fa-github"></i
    ></a>
  </section>
  
</div>
<div>
  <h2>InHouse Services</h2>
  <p>empower millions of service professeionals by delivering services
              at home in a way what has been experienced before
</p>
<p>Contact No: 8698438659    &ensp; &ensp; &ensp;    Gmail: Inhouseservices7@gmail.com</p>

  </div>


<div class="text-center p-3" style={{backgroundcolor: 'rgba(0, 0, 0, 0.2)'}}>
  © 2021 Copyright :
  <a class="text-white" href="localhost:3000"> Inhouseservices.com</a>
</div>

</footer>




    
    
  );
}
