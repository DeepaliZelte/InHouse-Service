import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./admin-login.component.css";
import { useState } from "react";
import axios from "axios";
import handyman from "./assets/images/handyman.png";
import { Navbar } from "./Navbar";
import swal from "sweetalert";

function ForgotPass() {

  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");

  localStorage.setItem("role",role);

  const regex =
    /^([a-zA-Z0-9_\.\-\ ])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  const handleForm = (e) => {
    e.preventDefault();
    if (email === "") {
      swal("error", "please enter valid details", "error");
    } else if (!regex.test(email)) {
      swal("Error!", "Please Enter Valid Email Address", "error");
    } else {
      checkUser();
    }
  };

  const checkUser = async () => {
    let user = null;
    
   if (role === "customer") {
      user = { custEmail: email};
      const res = await axios.post("http://localhost:8081/forgetcustPass", user);
      if (res.data === "success") {
       
        swal("success", "Your password sent on your email Successfully!!", "success");
        
      } else {
        swal("error", "Invalid Credintial please enter valid Email", "error");
      }
    } else if (role === "employee") {
      user = { empEmail: email};
      const res = await axios.post("http://localhost:8081/forgetPass", user);
      if (res.data === "success") {
        
        swal("success", "Your password sent on your email Successfully!!!", "success");
         
      } else {
        swal("error", "Invalid Credintial please enter valid Email", "error");
      }
    } else {
      setRole("");
    }
  };

  return (
    <>
      <Navbar />
      <div>
        <div
          class="container border-dark justify-content-center mt-3 mb-5 "
          style={{ display: "block", padding: "20",border:"2px solid black",backgroundColor:"" }}
        >
          <div class="row">
            <div class="col-2 mt-3 "></div>
            <div class="col-8 mt-3">
              <div class="row">
                <div class="col-sm-12 col-md-8 col-lg-6">
                  <img
                    src={handyman}
                    style={{ width: "100%", height: "100%" }}
                  />
                </div>
                <div class="col-sm-12 col-md-8 col-lg-6">
                  <form
                    class="Registration-form"
                    onsubmit=" return callvalidation()"
                  >
                    <div>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="50"
                        height="50"
                        fill="currentColor"
                        class="bi bi-person-fill"
                        viewBox="0 0 16 16"
                      >
                        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                      </svg>
                    </div>
                    <div class="inside-form mt-3" style={{ color: "black" }}>
                      <center>
                        <h2>Forgot Password!!</h2>
                      </center>
                    </div>
                    <div class="row">
                     
                      <div class="col-sm-4">
                        <input
                          type="radio"
                          class="btn-check"
                          name="options"
                          id="option2"
                          value="customer"
                          onChange={(e) => {
                            setRole(e.target.value);
                          }}
                        />
                        <label class="btn btn-secondary m-4" for="option2">
                          Customer
                        </label>
                      </div>
                      <div class="col-sm-4">
                        <input
                          type="radio"
                          class="btn-check"
                          name="options"
                          id="option3"
                          value="employee"
                          onChange={(e) => {
                            setRole(e.target.value);
                          }}
                        />
                        <label class="btn btn-secondary m-4" for="option3">
                          Employee
                        </label>
                      </div>
                    </div>

                    <div class="form-group">
                      <div>
                        <lable
                          id="inputGroup-sizing-lg"
                          style={{ height: 5, position: "left" }}
                        >
                          Email
                        </lable>
                      </div>
                      <input
                        type="email"
                        class="form-control m-2"
                        aria-label="Email"
                        name="adminEmail"
                        id="adminEmail"
                        aria-describedby="inputGroup-sizing-sm"
                        required
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    <div class="form-group">
                      <button
                        class="btn btn-secondary m-2"
                        type="button"
                        onClick={(handleForm)}
                      >
                        Submit
                      </button>
                     
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-2 mt-2"></div>
      </div>

         </>
  );
}

export default ForgotPass;
