import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./homepage.component.css";
import two from "./assets/2.jpg";
import { Navbar } from "./Navbar";

function Homepagecomponent() {
  return ( 
    <>
  <Navbar />
    <div>
      {/**  <!-----------------------------------Slider---------------------------------->*/}
      <div
        id="carouselExampleSlidesOnly"
        class="carousel slide mx-2 mt-0"
        data-bs-ride="carousel"
      >
        <div class="carousel-inner m-0 p-0">
          <div class="carousel-item active">
            <img
              src={two}
              class="d-block w-100 rounded"
              alt="..."
            />
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="..." />
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="..." />
          </div>
        </div>
      </div>

      {/** <!------------------------------Cards--------------------------------> */}
      <div class="row mt-4">
        <div class="card-group mt-3">
          <div class="card ">
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <img src="https://img.icons8.com/cute-clipart/64/000000/hammer.png" />
            </div>
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              
            </div>

            <div class="card-body">
              <div
                style={{
                  display: "flex",
                  alignitems: "center",
                  justifycontent: "center",
                }}
              ></div>

              <p class="card-text ">
                Furniture related services become a need every now and then.
                Hence, having a fast method of finding carpenters can help in
                saving a lot of time and money. Our network brings a sense of
                convenience and safety for the customers.
              </p>
              
            </div>
          </div>

          <div class="card">
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <img src="https://img.icons8.com/pastel-glyph/64/000000/car--v2.png" />
            </div>

            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <li>
                <a href="./Adminlogincomponent">Driver</a>
              </li>
            </div>

            <div class="card-body">
              <div
                style={{
                  display: "flex",
                  alignitems: "center",
                  justifycontent: "center",
                }}
              ></div>
              <p class="card-text">
                We help you with travel within the city and outside the city
                without getting back of the wheels, just skip all the traffic
                jams and relax in the comfort of your car, our trained and
                groomed drivers will ensure your safety.
              </p>
             
            </div>
          </div>

          <div class="card">
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <img src="https://img.icons8.com/nolan/64/paint-brush.png" />
            </div>
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <a href="https://icons8.com/icon/52992/paint-brush"></a>
              <li>
                <a href="./Adminlogincomponent">Painter</a>
              </li>
            </div>

            <div class="card-body">
              <div
                style={{
                  display: "flex",
                  alignitems: "center",
                  justifycontent: "center",
                }}
              ></div>
              <p class="card-text">
                You can search House Painters in your city on the basis of your
                location, popularity, ratings and reviews. To get the best
                offers from business listed with instanthire, click on the Best
                Deals tab beside listings and fillup the requirements.
              </p>
              
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-4">
        <div class="card-group mt-3 mb-2">
          <div class="card">
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <img src="https://img.icons8.com/nolan/64/planner.png" />
            </div>
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <li>
                <a href="./Adminlogincomponent">Event Planner</a>
              </li>
            </div>
            <div class="card-body">
              <div
                style={{
                  display: "flex",
                  alignitems: "center",
                  justifycontent: "center",
                }}
              ></div>

              <p class="card-text">
                To make a successful event be it a formal or informal event, be
                it a big or small event requires a lot of planning, managing
                everything, making things available at right time at right
                place. Our network will definitely help to fulfill your dream{" "}
              </p>
              
            </div>
          </div>

          <div class="card">
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <img src="https://img.icons8.com/color/96/000000/cook-male--v1.png" />
            </div>
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <li>
                <a href="./Adminlogincomponent">Chef</a>
              </li>
            </div>

            <div class="card-body">
              <div
                style={{
                  display: "flex",
                  alignitems: "center",
                  justifycontent: "center",
                }}
              ></div>
              <p class="card-text">
                You can search Cooks On Hire in Thane West on the basis of your
                location, popularity, ratings and reviews on instanthire.
              </p>
              
            </div>
          </div>

          <div class="card ">
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <img src="https://img.icons8.com/color/96/000000/plumber.png" />
            </div>
            <div
              style={{
                display: "flex",
                alignitems: "center",
                justifycontent: "center",
              }}
            >
              <li>
                <a href="./Adminlogincomponent">Plumber</a>
              </li>
            </div>
            <div class="card-body">
              <div
                style={{
                  display: "flex",
                  alignitems: "center",
                  justifycontent: "center",
                }}
              ></div>
              <p class="card-text">
                You can search Plumbers in Thane West on the basis of your
                location, popularity, ratings and reviews on instanthire.{" "}
              </p>
              
            </div>
          </div>
        </div>
      </div>

    </div>
    </>
  );
}
export default Homepagecomponent;
