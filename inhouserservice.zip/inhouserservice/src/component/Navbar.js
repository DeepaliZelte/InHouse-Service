import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import "./NavBar.css";
export function Navbar() {
  const [click, setClick] = useState(false);

  const handleClick = () => setClick(!click);
  return (

  < >


<nav className="navbar sticky-top">

        <div className="nav-container ">
        
         <ul className={click ? "nav-menu active" : "nav-menu"}>
          <li>
          <a class="navbar-brand" href="/Homepagecomponent" style={{color:"orange"}}>Inhouse Services</a>
            </li>
            <li className="nav-item">
              <NavLink
                exact
                to="/Homepagecomponent"
                activeClassName="active"
                className="nav-links"
                onClick={handleClick}
              >
                Home
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                exact
                to="/AboutUs"
                activeClassName="active"
                className="nav-links"
                onClick={handleClick}
              >
                About Us
              </NavLink>
            </li>
            
            <li className="nav-item">
              <NavLink
                exact
                to="/ContactUs"
                activeClassName="active"
                className="nav-links"
                onClick={handleClick}
              >
                Contact Us
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                exact
                to="/Adminlogincomponent"
                activeClassName="active"
                className="nav-links"
                onClick={handleClick}
              >
                Login/Regester
              </NavLink>
            </li>
          </ul>
          <div className="nav-icon" onClick={handleClick}>
            <i className={click ? "fas fa-times" : "fas fa-bars"}></i>
          </div>
        </div>
      </nav>






    
    </>
  );
}
