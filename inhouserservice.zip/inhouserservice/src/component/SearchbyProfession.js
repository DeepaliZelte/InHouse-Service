import axios from "axios";
import { useEffect, useState } from "react";
import CustNav from "./CustNav";
import swal from "sweetalert";
function SearchByProfession() {
  const [prof, setProf] = useState([]);
  const [selectedProfession, setSelectedProfession] = useState("");
  const [employeelist, setEmployeeList] = useState([]);

  useEffect(() => {
    allProf();
  }, []);

  const getEmpList = async () => {
    console.log("in list");
    const emp = { profession: selectedProfession };
    const res = await axios.post("http://localhost:8081/getbyprofession", emp);
    setEmployeeList(res.data);
  };
  useEffect(() => {
    if(localStorage.getItem("role")==="null" || localStorage.getItem("role")!="customer" )
{
  window.location.href="/Adminlogincomponent";
}
    getallEmpList();
  }, []);

  const getallEmpList = async () => {
    console.log("in list");
    const res = await axios.get("http://localhost:8081/employeeList");

    setEmployeeList(res.data);
  };

  const allProf = async () => {
    const profs = await axios.get("http://localhost:8081/getallprofession");
    setProf(profs.data);
  };

  var today = new Date();
  var date =
    today.getDate() + "/" + (today.getMonth() + 1) + "/" + today.getFullYear();

  const HireEmp = async (id) => {
    const hiredetails = {
      cust: { custId: localStorage.getItem("userId") },
      emp: { empId: id },
      hireDate: date,
      hireStatus: "pending",
    };

    await axios.post("http://localhost:8081/addHire", hiredetails);
    swal("","request sent","success");
  };


  return (
    <>
      <CustNav/>
    <div class="col-12 ">
      <div class="col-6 mx-auto">
        <select
          class="form-select mx-auto col-7 w-100"
          onChange={(e) => {
            setSelectedProfession(e.target.value);
          }}
          aria-label="Default select example"
        >
          <option selected>Select Profession</option>
          {prof.map((item) => {
            return <option value={item.profession}>{item.profession}</option>;
          })}
        </select>
        <input
          type="button"
          onClick={() => {
            getEmpList();
          }}
          class=" col-4 mb-3 btn mx-auto btn-danger"
          value="search"
        ></input>
      </div>

<div class="m-5">
<div class="row">
            
          {employeelist.map((item) => {
            return (
              <div class="card m-auto mb-3 card-text d-flex" style={{width:"450px" }}>
              <div class=" card text-dark mb-3" style={{color:'black'}}>
              <th style={{fontSize:'30px',color:"#8A2BE2"}}> {item.empName}</th><hr/>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>City : {item.empCity}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Contact : {item.empContact}</th>
            <th style={{fontSize:'22px',fontWeight:'bold'}}>Profession : {item.profession}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Exp(Yrs) : {item.empExperience}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Rate/hr : {item.empRatePerHr}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Email : {item.empEmail}</th>

            <th style={{fontSize:'18px',fontWeight:'bold'}}>Status : {item.empStatus}</th>
            
            <div class="row card-footer m-2 ">
                  <button
                    class="btn btn-primary mb-1"
                    onClick={() => {
                      HireEmp(item.empId);
                    }}
                  >
                    Hire
                  </button>
                 </div>
                 </div>
                 </div>
            );
          })}
        </div>
    </div>
    </div>
    </>
  );
}

export default SearchByProfession;
