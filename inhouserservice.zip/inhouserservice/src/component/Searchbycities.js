import axios from "axios";
import { useEffect, useState } from "react";
import CustNav from "./CustNav";
import swal from "sweetalert";
function Searchbycities() {
  const [city, setCity] = useState([]);
  const [selectedCity, setSelectedCity] = useState("");
  const [employeelist, setEmployeeList] = useState([]);

  useEffect(() => {
    cities();
  }, []);

  const getEmpList = async () => {
    console.log("in list");
    const emp = { empCity: selectedCity };
    const res = await axios.post("http://localhost:8081/getbycity", emp);
    setEmployeeList(res.data);
  };
  useEffect(() => {
    if(localStorage.getItem("role")==="null" || localStorage.getItem("role")!="customer" )
{
  window.location.href="/Adminlogincomponent";
}
    getallEmpList();
  }, []);

  const getallEmpList = async () => {
    console.log("in list");
    const res = await axios.get("http://localhost:8081/employeeList");

    setEmployeeList(res.data);
  };

  const cities = async () => {
    const City1 = await axios.get("http://localhost:8081/getallcities");
    setCity(City1.data);
  };

  var today = new Date();
  var date =
    today.getDate() + "/" + (today.getMonth() + 1) + "/" + today.getFullYear();

  const HireEmp = async (id) => {
    const hiredetails = {
      cust: { custId: localStorage.getItem("userId") },
      emp: { empId: id },
      hireDate: date,
      hireStatus: "pending",
    };

    await axios.post("http://localhost:8081/addHire", hiredetails);
    swal("","request sent","success");
  };

  return (
    <>
      <CustNav/>
    
    <div class="col-12 ">
      <div class="col-6 mx-auto">
        <select
          class="form-select mx-auto col-7 w-100"
          onChange={(e) => {
            setSelectedCity(e.target.value);
          }}
          aria-label="Default select example"
        >
          <option selected>Select City</option>
          {city.map((item) => {
            return <option value={item.empCity}>{item.empCity}</option>;
          })}
        </select>
        <input
          type="button"
          onClick={() => {
            getEmpList();
          }}
          class=" col-4 mb-3 btn mx-auto btn-danger"
          value="search"
        ></input>
      </div>
 <div class="m-5">
<div class="row">
            
          
          {employeelist.map((item) => {
            return (
              <div class="card m-auto mb-3 card-text d-flex" style={{width:"450px"}}>
              <div class=" card text-dark " style={{color:'black'}}>
              <th style={{fontSize:'30px',color:"#8A2BE2"}}> {item.empName}</th><hr/>
             <th style={{fontSize:'18px',fontWeight:'bold'}}>City : {item.empCity}</th>
            <th  style={{fontSize:'18px',fontWeight:'bold'}}>Contact : {item.empContact}</th>
            <th  style={{fontSize:'22px',fontWeight:'bold'}}>Profession : {item.profession}</th>
            <th  style={{fontSize:'18px',fontWeight:'bold'}}>Exp(Yrs) : {item.empExperience}</th>
            <th  style={{fontSize:'18px',fontWeight:'bold'}}>Rate/hr : {item.empRatePerHr}</th>
            <th  style={{fontSize:'18px',fontWeight:'bold'}}>Email : {item.empEmail}</th>

            <th  style={{fontSize:'20px',fontWeight:'bold'}}>Status : {item.empStatus}</th>
            <div class="row card-footer m-1  ">
                  <button
                    class="btn btn-primary"
                    onClick={() => {
                      HireEmp(item.empId);
                    }}
                  >
                    Hire
                  </button>
                  </div>
                </div>
                </div>
            );
          })}
       </div>
    </div>
    </div>
    </>
  );
}

export default Searchbycities;
