import axios from "axios";
import { useEffect, useState } from "react";
import CustNav from "./CustNav";

function ViewComplaints() {
  const [CompList, setCompList] = useState([]);
  useEffect(() => {
    if(localStorage.getItem("role")==="null" || localStorage.getItem("role")!="customer" )
{
  window.location.href="/Adminlogincomponent";
}
    getCompList();
  }, []);

  const getCompList = async () => {
    const comp = { cust: { custId: localStorage.getItem("userId") } };
    const res = await axios.post("http://localhost:8081/getcompbycust", comp);
    setCompList(res.data);
  };
  return (
    <>
      <CustNav />
      <div class="m-5">

        <div class="row">

          {CompList.map((item) => {
            return (
              <div class="card m-auto mb-3 card-text d-flex" style={{ width: "450px" }}>
                <div class=" card text-dark" style={{ color: 'black'}}>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>Complaint Against : {item.emp.empName}</th>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>Issue : {item.issue}</th>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>description : {item.discription}</th>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>date : {item.date}</th>
                  <th style={{fontSize:'18px',fontWeight:'bold'}}>status : {item.status}</th>
                </div>
              </div>
            );
          })}

        </div>
      </div>
    </>
  );
}

export default ViewComplaints;
