import axios from "axios";
import { useEffect, useState } from "react";
import SweetAlert from "sweetalert";
import CustNav from "./CustNav";

function BookedList() {
  const [hirelist, setHirelist] = useState([]);

  useEffect(() => {

    if(localStorage.getItem("role")==="null" || localStorage.getItem("role")!="customer" )
{
  window.location.href="/Adminlogincomponent";
}
    getHireList();
  }, []);

  const getHireList = async () => {
    const hire = { cust: { custId: localStorage.getItem("userId") } };
    const res = await axios.post("http://localhost:8081/gethirebycust", hire);
    setHirelist(res.data);
  };

  const postComp=(empid)=>{
    localStorage.setItem("empid",empid);
    window.location.href="/Complaint"
  }

  const CancelBooking = async (id) => {
    const hire = { hireId: id };
    const res = await axios.post("http://localhost:8081/cancelbooking", hire);
    SweetAlert("", res.data, "");
    window.location.href = "";
  };


  return (
    <>
      <CustNav/>
<div class="m-5">
<div class="row"></div>
          {hirelist.map((item) => {
            return (
              <div class="card m-auto mb-3 card-text d-flex" style={{width:"450px"}}>
              <div class=" card text-dark " style={{color:'black'}}>
               <th style={{fontSize:'30px',color:"#8A2BE2"}}>{item.emp.empName}</th><hr/>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Address : {item.emp.empAddress}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>City : {item.emp.empCity}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Contact : {item.emp.empContact}</th>
            <th style={{fontSize:'22px',fontWeight:'bold'}}>Profession : {item.emp.profession}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Rate/hr : {item.emp.empRatePerHr}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Date : {item.hireDate}</th>
            <th style={{fontSize:'18px',fontWeight:'bold'}}>Status : {item.hireStatus}</th>
           
            <div class="row card-footer m-2 ">
                  <button
                    type="button"
                    class="btn btn-danger m-1"
                    onClick={() => {
                      CancelBooking(item.hireId);
                    }}
                  >
                    Cancel
                  </button>
                
                  <button type="button" class="btn btn-danger m-1" onClick={()=>{postComp(item.emp.empId)}}>
                    Post Complaint
                  </button>
               </div>
               </div>
               </div>
            );
          })}
        </div>
        </>
        
  );
}

export default BookedList;
