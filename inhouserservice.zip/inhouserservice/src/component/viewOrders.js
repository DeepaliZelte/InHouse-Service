import axios from "axios";
import { useEffect, useState } from "react";
import SweetAlert from "sweetalert";
import Employeehomepagecomponent from "./Employeehomepagecomponent";

function ViewOrders() {
  const [hirelist, setHirelist] = useState([]);

  useEffect(() => {
    if (localStorage.getItem("role") === "null" || localStorage.getItem("role") != "employee") {
      window.location.href = "/Adminlogincomponent";
    }
    getHireList();
  }, []);

  const getHireList = async () => {
    const hire = { emp: { empId: localStorage.getItem("userId") } };
    const res = await axios.post("http://localhost:8081/gethirebyemp", hire);
    setHirelist(res.data);
  };

  const acceptBooking = async (id) => {
    const hire = { hireId: id };
    const res = await axios.post("http://localhost:8081/acceptbooking", hire);
    SweetAlert("success", res.data, "success");
    window.location.href = "";
  };

  const rejectBooking = async (id) => {
    const hire = { hireId: id };
    const res = await axios.post("http://localhost:8081/rejectbooking", hire);
    SweetAlert("", res.data, "");
    window.location.href = "";
  };


  return (
    <>
      <Employeehomepagecomponent />
      <div class="m-5">

        <div class="row">
          {hirelist.map((item) => {
            if (
              item.hireStatus === "pending" ||
              item.hireStatus === "accepted"
            ) {
              return (
                <div class="card m-auto mb-3 card-text d-flex" style={{ width: "450px" }}>
                  <div class=" card text-dark" style={{ color: 'black' }}>
                    <th style={{fontSize:'30px',color:"#8A2BE2"}}>{item.cust.custName}</th><hr/>
                    <th style={{fontSize:'18px',fontWeight:'bold'}}>Address : {item.cust.custAddress}</th>

                    <th style={{fontSize:'18px',fontWeight:'bold'}}>Contact : {item.cust.custContact}</th>

                    <th style={{fontSize:'18px',fontWeight:'bold'}}>Hire Date : {item.hireDate}</th>
                    <th style={{fontSize:'18px',fontWeight:'bold'}}>Status : {item.hireStatus}</th>
                    <div class="row card-footer m-1  ">
                      <button
                        type="button"
                        class="btn btn-success mb-2"
                        onClick={() => {
                          acceptBooking(item.hireId);
                        }}
                      >
                        Accept
                      </button>

                      <button
                        type="button"
                        class="btn btn-danger"
                        onClick={() => {
                          rejectBooking(item.hireId);
                        }}
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                </div>
              );
            }
          })}
        </div>
      </div>
    </>
  );
}

export default ViewOrders;
